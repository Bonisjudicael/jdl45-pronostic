# JDL45 PRONOSTIC — première maquette

Cette première version comprend :
- une page publique adaptée aux mobiles ;
- un bouton de thème nuit/jour ;
- la plateforme WINWINBET avec code promo et lien laissés vides ;
- des sections pour les liens de communication ;
- un lecteur audio prêt à utiliser quand un lien audio sera disponible ;
- une interface de démonstration pour ajouter/supprimer des plateformes et liens.

## Important : limites de la démo

Ouvrez `index.html` dans un navigateur pour essayer l'interface. La démo sauvegarde les changements dans le stockage local du navigateur : ils ne sont visibles que sur cet appareil et ce navigateur. Le formulaire d'administration n'est **pas** une vraie authentification. Ne publiez pas cette démo comme un site administrable en production et n'y mettez aucun mot de passe réel.

## Pour rendre le site public et administrable

Il faut connecter une base de données et une authentification, par exemple avec Supabase :
1. Créez un projet Supabase.
2. Créez un utilisateur admin dans Authentication.
3. Exécutez `supabase-schema.sql` dans le SQL Editor.
4. Intégrez le client Supabase dans `app.js` : authentification e-mail/mot de passe, lecture publique des données actives, et opérations d'écriture réservées à l'admin.
5. Ajoutez des politiques RLS strictes afin que seuls les administrateurs désignés puissent écrire.
6. Déployez le site sur un hébergeur HTTPS (par exemple Vercel ou Netlify).

`config.js` est volontairement vide. La clé publique/anon peut être utilisée côté navigateur avec RLS correctement configuré ; ne placez jamais la clé `service_role` dans le site.

## Données initiales

WINWINBET est créée avec les champs du code promo et du lien d'inscription vides. Ajoutez uniquement vos propres liens et codes autorisés lorsque vous les aurez.
